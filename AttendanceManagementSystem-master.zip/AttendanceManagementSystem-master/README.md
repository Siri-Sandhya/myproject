# AttendanceManagementSystem
Abstract:

The Attendance Android app is an innovative solution that helps manage attendance, notifications, and profiles for educational institutions. The app is developed using Java programming language and Firebase as the database in Android Studio. The app has three logins using email and password through Firebase authentication - Admin, Teacher, and Student. The Admin can access the entire database, register students and teachers, and send notifications to them. The Teacher can take attendance, view attendance, view notifications, and update their profile. The Student can view their attendance, view notifications, and update their profile. The app is user-friendly, efficient, and eliminates the manual process of taking attendance. The future enhancement of the app includes adding face recognition for attendance and seeking permission from students to teachers before sharing their personal information. The app has the potential to save time, reduce errors, and make the attendance management process more efficient for  educational institutions. 


This is Android studio based App made using java programming language and firebase is used as database. 

Done by: kavili Sai Dinesh, Katta Gurunadham, Jetti Vinay
