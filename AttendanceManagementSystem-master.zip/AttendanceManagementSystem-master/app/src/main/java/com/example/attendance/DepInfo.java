package com.example.attendance;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DepInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dep_info);
    }
}